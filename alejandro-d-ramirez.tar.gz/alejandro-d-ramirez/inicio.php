<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <h1>La Internet</h1>
    <marquee>Bienvenidos al mundo de la internet</marquee>
    <h2>Bienvenido [NOMBRE]</h2>
    <h3>¿Es usted un ganador?</h3>

    <h3>Algunos sitios interesantes:</h3>
    <ul>
      <li>
        <a href="https://google.com">Google</a>
      </li>
      <li>
        <a href="https://facebook.com">Facebook</a>
      </li>
      <li>
        <a href="https://twitter.com">Twitter</a>
      </li>
    </ul>

    <?php
      for ($i=2; $i<=20; $i=$i+2) {
         echo "2 x ". ($i/2). "= " . $i . "<br>";
      }
     ?>

     <br>

  <!-- Un bucle while que cuente desde 100 hasta 85 (fíjate que en este caso es decreciente). -->
<?php

$i = 100;
while ($i >= 85) {
    echo $i--. "<br>";  /* el valor presentado sería
                   $i antes del incremento
                   (post-incremento) */
}



 ?>


  </body>
</html>
